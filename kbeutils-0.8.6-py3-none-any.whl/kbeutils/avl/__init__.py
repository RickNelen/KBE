#!/usr/bin/env python
# -*- coding: utf-8 -*-

""" AVL wrapper for ParaPy
"""

import os.path

from avlwrapper import Spacing, Symmetry

from .primitives import (Configuration, Surface, Body, Section, FileAirfoil,
                        NacaAirfoil, DataAirfoil, BodyProfile, Control,
                        DesignVar, ProfileDrag, SurfaceFromCurves, SectionFromCurve)

from .interface import Case, Parameter, Interface

AVL_MODULE_DIR = os.path.dirname(__file__)
