#!/usr/bin/env python
# -*- coding: utf-8 -*-

""" AVL geometric primitives
"""

import os.path
from math import degrees, copysign

from parapy.core import Input, Attribute, Base
from parapy.geom import (LineSegment, rotate, translate, Vector,
                         GeomBase, RevolvedSurface, Point, SewnShell,
                         RuledSurface, VX, Position, VY)

import avlwrapper
from kbeutils.geom import (Plane,
                           SeligAirfoilCurve, AirfoilCurve, Naca4AirfoilCurve)
from kbeutils.globs import ICON_DIR
from kbeutils.avl.interface import _get_wrapper_object


class Configuration(Base):
    """AVL aircraft configuration"""

    __icon__ = os.path.join(ICON_DIR, 'avl_configuration.png')

    #: aircraft name
    #: :type: str
    name = Input(defaulting=True)

    #: reference planform area for normalisation
    #: :type: float
    reference_area = Input()

    #: reference chord for normalisation
    #: :type: float
    reference_chord = Input()

    #:  reference span for normalisation
    #: :type: float
    reference_span = Input()

    #: reference point for moment calculations
    #: :type: Point
    reference_point = Input(Point())

    #: mach number
    #: :type: float
    mach = Input(0.0)

    #: addition profile drag
    #: :type: float
    cd_p = Input(0.0)

    #: symmetry normal to y-axis
    #: :type: Symmetry
    y_symmetry = Input(avlwrapper.Symmetry.none)

    #: symmetry normal to z-axis
    #: :type: Symmetry
    z_symmetry = Input(avlwrapper.Symmetry.none)

    #: z-normal symmetry plane offset
    #: :type: float
    z_symmetry_plane = Input(0.0)

    #: AVL surfaces
    #: :type: collections.Sequence[Surface]
    surfaces = Input([])

    #: AVL bodies
    #: :type: collections.Sequence[Body]
    bodies = Input([])

    @Attribute
    def wrapper_object(self):
        return avlwrapper.Geometry(name=self.name,
                                   reference_area=self.reference_area,
                                   reference_chord=self.reference_chord,
                                   reference_span=self.reference_span,
                                   reference_point=self.reference_point,
                                   mach=self.mach,
                                   cd_p=self.cd_p,
                                   y_symmetry=self.y_symmetry,
                                   z_symmetry=self.z_symmetry,
                                   z_symmetry_plane=self.z_symmetry_plane,
                                   surfaces=[_get_wrapper_object(obj)
                                             for obj in self.surfaces],
                                   bodies=[_get_wrapper_object(obj)
                                           for obj in self.bodies])


class _Component(GeomBase):
    """Base class of Surface and Body"""

    __icon__ = os.path.join(ICON_DIR, 'avl_component.png')

    #: (unique) surface name
    #: :type: str
    name = Input(defaulting=True)

    #: mirror the surface with a plane normal to the y-axis
    #:  see AVL documentation
    #: :type: float or None
    y_duplicate = Input(None)

    #: x, y, z scaling factors
    #: :type: Vector or None
    scaling = Input(None)


class Surface(_Component, SewnShell):
    """AVL surface"""

    #: number of chordwise panels
    #: :type: int
    n_chordwise = Input()

    #: chordwise distribution type. See `Spacing` enum
    #: :type: Spacing or float
    chord_spacing = Input()

    #: surface sections
    #: :type: collections.Sequence[Section]
    sections = Input()

    #: number of spanwise panels
    #: :type: int or None
    n_spanwise = Input(None)

    #: spanwise distribution type. See `Spacing` enum
    #: :type: Spacing or float or None
    span_spacing = Input(None)

    #: component number for surface grouping. for detailed
    #:  explanation see AVL documentation
    #: :type: int or None
    component = Input(None)

    #: surface incidence angle
    #: :type: float or None
    angle = Input(None)

    #: set custom drag polar.
    #:  See AVL documentation for details.
    #: :type: ProfileDrag or None
    profile_drag = Input(None)

    #: disables the kutta-condition on the surface
    #:  (will shed no wake)
    #: :type: bool
    no_wake = Input(False)

    #: surface will not be influenced
    #:  by freestream direction changes (for wind-tunnel walls, etc.)
    #: :type: bool
    fixed = Input(False)

    #: surface forces are not included in the totals
    #: :type: bool
    no_loads = Input(False)

    @Attribute
    def built_from(self):
        faces = []
        for start, end in zip(self.sections[:-1],
                              self.sections[1:]):
            faces.append(RuledSurface(curve1=start, curve2=end))
        return faces

    @Attribute
    def wrapper_object(self):
        return avlwrapper.Surface(name=self.name,
                                  n_chordwise=self.n_chordwise,
                                  chord_spacing=self.chord_spacing,
                                  sections=[_get_wrapper_object(obj)
                                            for obj in self.sections],
                                  n_spanwise=self.n_spanwise,
                                  span_spacing=self.span_spacing,
                                  component=self.component,
                                  y_duplicate=self.y_duplicate,
                                  scaling=self.scaling,
                                  angle=self.angle,
                                  profile_drag=_get_wrapper_object(
                                      self.profile_drag),
                                  no_wake=self.no_wake,
                                  fixed=self.fixed,
                                  no_loads=self.no_loads)


class SurfaceFromCurves(Surface):
    """Surface derived from ParaPy curves"""

    curves_in = Input()

    @Attribute
    def _airfoil_curves(self):
        return [AirfoilCurve(curve_in=curve)
                for curve in self.curves_in]

    @Attribute
    def _le_points(self):
        return [airfoil.le_point
                for airfoil in self._airfoil_curves]

    @Attribute
    def _chord_vectors(self):
        return [airfoil.chord_vector
                for airfoil in self._airfoil_curves]

    @Attribute
    def _streamwise_planes(self):
        planes = []
        for idx in range(len(self._le_points) - 1):
            le_vector = self._le_points[idx].vector_to(self._le_points[idx + 1])
            normal = VX.cross(le_vector)
            planes.append(Plane(reference=self._le_points[idx],
                                normal=normal,
                                binormal=VX))
        return planes

    @Attribute
    def angle(self):
        return self._streamwise_planes[0].projected_angle(self._chord_vectors[0])

    @Attribute
    def _section_angles(self):
        return [0] + [plane.projected_angle(chord_vector)
                      for plane, chord_vector in zip(self._streamwise_planes,
                                                     self._chord_vectors[1:])]

    @Attribute
    def sections(self):
        return [SectionFromCurve(curve_in=curve,
                                 angle=angle)
                for (curve, angle) in zip(self._airfoil_curves,
                                          self._section_angles)]


class Body(_Component, RevolvedSurface):
    #: number of panels on body
    #: :type: int
    n_body = Input()

    #: panel distribution
    #: :type: Spacing
    body_spacing = Input()

    #: body section profile
    #: :type: BodyProfile
    body_section = Input()

    @Attribute
    def basis_curve(self):
        return self.body_section

    @Attribute
    def direction(self):
        return self.position.Vx

    @Attribute
    def wrapper_object(self):
        return avlwrapper.Body(name=self.name,
                               n_body=self.n_body,
                               body_spacing=self.body_spacing,
                               body_section=_get_wrapper_object(
                                   self.body_section),
                               y_duplicate=self.y_duplicate,
                               scaling=self.scaling,
                               translation=self.position.point)


class Section(LineSegment):
    """AVL section positioned at the leading edge point"""

    __icon__ = os.path.join(ICON_DIR, 'avl_section.png')

    #: the chord length
    #: :type: float
    chord = Input()

    #: the section angle. This will rotate the normal vectors
    #:  of the VLM panels. The panels will remain in stream-wise direction
    #: :type: float or None
    angle = Input(0)

    #: number of spanwise panels in the next wing segment
    #: :type: int or None
    n_spanwise = Input(None)

    #: panel distribution type. See `Spacing` enum
    #: :type: Spacing or float or None
    span_spacing = Input(None)

    #: Airfoil to be used at the section. AVL uses the airfoil
    #:  camber to calculate the surface normals.
    #: :type: _AirfoilMixin or collections.Sequence[None]
    airfoil = Input(None)

    #: perturbation of the local inflow angle by a set of
    #:  design variables.
    #: :type: collections.Sequence[DesignVar] or collections.Sequence[none]
    design_vars = Input([None])

    #: defines a hinge deflection
    #: :type: collections.Sequence[Control] or collections.Sequence[None]
    controls = Input([None])

    #: scales the effective dcl/dalpha of the section
    #: :type: float
    cl_alpha_scaling = Input(None)

    #: set custom drag polar.
    #:  See AVL documentation for details.
    #: :type: ProfileDrag or None
    profile_drag = Input(None)

    #: angle rotation axis (just for visualization purposes)
    #: :type: Vector
    rot_axis = Input(VY)

    color = Input('yellow')
    line_thickness = Input(3)

    @Attribute
    def start(self):
        return self.position.point

    @Attribute
    def end(self):
        end_pos = translate(rotate(self.position,
                                   self.rot_axis, self.angle, deg=True),
                            'x', self.chord)
        return end_pos.point

    @Attribute
    def wrapper_object(self):
        return avlwrapper.Section(leading_edge_point=self.position.point,
                                  chord=self.chord,
                                  angle=self.angle,
                                  n_spanwise=self.n_spanwise,
                                  span_spacing=self.span_spacing,
                                  airfoil=_get_wrapper_object(self.airfoil),
                                  design_vars=[_get_wrapper_object(obj)
                                               for obj in self.design_vars],
                                  controls=[_get_wrapper_object(obj)
                                            for obj in self.controls],
                                  cl_alpha_scaling=self.cl_alpha_scaling,
                                  profile_drag=_get_wrapper_object(
                                      self.profile_drag))


class SectionFromCurve(Section):
    """Section derived from a ParaPy curve"""

    curve_in = Input()
    n_points = Input(200)

    @Input
    def chord(self):
        return self.airfoil_curve.chord_length

    @Attribute
    def rot_axis(self):
        return -self.airfoil_curve.plane_normal

    @Input
    def angle(self):
        vec = self.airfoil_curve.chord_vector
        angle, axis = vec.angle_and_axis(VX)
        return degrees(copysign(angle, -1*sum(axis)))

    @Attribute
    def airfoil_curve(self):
        if not isinstance(self.curve_in, AirfoilCurve):
            return AirfoilCurve(curve_in=self.curve_in,
                                n_points=self.n_points)
        else:
            return self.curve_in

    @Attribute
    def airfoil(self):
        return DataAirfoil(curve_in=self.airfoil_curve.normalized_airfoil)

    @Attribute
    def position(self):
        return Position(self.airfoil_curve.le_point)


class _AirfoilMixin(Base):
    """Airfoil mixin class"""

    #: the x/c range x1..x2 from the coordinates to be assigned
    x1 = Input(None)
    x2 = Input(None)


class FileAirfoil(SeligAirfoilCurve, _AirfoilMixin):
    """Airfoil defined from a selig (.dat) file"""

    @Attribute
    def wrapper_object(self):
        return avlwrapper.FileAirfoil(self.filename,
                                      x1=self.x1,
                                      x2=self.x2)


class DataAirfoil(AirfoilCurve, _AirfoilMixin):
    """Airfoil defined from coordinates"""

    @Attribute
    def _xyz_data(self):
        return zip(*self.coordinates)

    @Attribute
    def wrapper_object(self):
        x, _, z = self._xyz_data
        return avlwrapper.DataAirfoil(x, z, x1=self.x1, x2=self.x2)


class NacaAirfoil(Naca4AirfoilCurve, _AirfoilMixin):
    """Airfoil defined by NACA4-series designation"""

    @Attribute
    def wrapper_object(self):
        return avlwrapper.NacaAirfoil(self.designation,
                                      x1=self.x1,
                                      x2=self.x2)


class BodyProfile(SeligAirfoilCurve, _AirfoilMixin):
    """Body profile from a selig (.dat) file"""

    @Attribute
    def wrapper_object(self):
        return avlwrapper.BodyProfile(self.filename,
                                      x1=self.x1,
                                      x2=self.x2)


class Control(Base):
    """Defines a hinge deflection"""

    __icon__ = os.path.join(ICON_DIR, 'avl_control.png')

    #: control name
    #: :type: str
    name = Input()

    #: control deflection gain
    #: :type: float
    gain = Input()

    #: x/c location of the hinge
    #: :type: float
    x_hinge = Input()

    #: sign of deflection for duplicated surface
    #: :type: int
    duplicate_sign = Input()

    #: hinge_vector. Defaults to Vector(0,0,0) which puts
    #:  the hinge vector along the hinge
    #: :type: Vector
    hinge_vector = Input(Vector(0, 0, 0))

    @Attribute
    def wrapper_object(self):
        return avlwrapper.Control(name=self.name,
                                  gain=self.gain,
                                  x_hinge=self.x_hinge,
                                  duplicate_sign=self.duplicate_sign,
                                  hinge_vector=self.hinge_vector)


class DesignVar(Base):
    """Defines a design variable on the section local inflow angle"""

    #: variable name
    #: :type: str
    name = Input()

    #: variable weight
    #: :type: float
    weight = Input()

    @Attribute
    def wrapper_object(self):
        return avlwrapper.DesignVar(name=self.name,
                                    weight=self.weight)


class ProfileDrag(Base):
    """ Specifies a simple profile-drag CD(CL) function.
    The function is parabolic between CL1..CL2 and
    CL2..CL3, with rapid increases in CD below CL1 and above CL3.
    See AVL documentation for details"""

    #: lift-coefficients
    #: :type: collections.Sequence[float] of length 3
    cl = Input()

    #: drag-coefficients
    #: :type: collections.Sequence[float] of length 3
    cd = Input()

    @Attribute
    def wrapper_object(self):
        return avlwrapper.ProfileDrag(cl=self.cl,
                                      cd=self.cd)
