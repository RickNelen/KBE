#!/usr/bin/env python
# -*- coding: utf-8 -*-

""" Surface
"""

import os.path

try:
    from OCC.Adaptor3d import Adaptor3d_CurveOnSurface
    from OCC.BRepAdaptor import BRepAdaptor_Curve2d
    from OCC.Geom2dAdaptor import Geom2dAdaptor_HCurve
    from OCC.GeomAdaptor import GeomAdaptor_HCurve, GeomAdaptor_HSurface
    from OCC.GeomFill import (GeomFill_SimpleBound, GeomFill_ConstrainedFilling,
                              GeomFill_BoundWithSurf)
except ImportError:
    from OCC.wrapper.Adaptor3d import Adaptor3d_CurveOnSurface
    from OCC.wrapper.BRepAdaptor import BRepAdaptor_Curve2d
    from OCC.wrapper.Geom2dAdaptor import Geom2dAdaptor_HCurve
    from OCC.wrapper.GeomAdaptor import GeomAdaptor_HCurve, GeomAdaptor_HSurface
    from OCC.wrapper.GeomFill import (GeomFill_SimpleBound,
                                      GeomFill_ConstrainedFilling,
                                      GeomFill_BoundWithSurf)
from parapy.core import Attribute, Input
from parapy.geom import Plane as _Plane
from parapy.geom.occ.surface import BSplineSurface_

from kbeutils.core import LengthInRange
from kbeutils.geom import find_edge_on_face


class Plane(_Plane):

    def projected_angle(self, vector):
        projected_vector = vector.project_on_plane(self.normal)
        return vector.angle_between(projected_vector)


class _ConstrainedFillingSurface(BSplineSurface_):
    max_degree = Input(11)
    max_segments = Input(30)

    do_check = Input(True)

    mesh_deflection = Input(1e-4)

    @Attribute
    def _Bounds(self):
        raise NotImplementedError("Don't use this class directly.")

    @Attribute
    def _ConstrainedFilling(self):
        builder = GeomFill_ConstrainedFilling(self.max_degree,
                                              self.max_segments)
        args = self._Bounds + [not self.do_check]
        builder.Init(*args)
        return builder

    @Attribute(private=True)
    def Handle_Geom_Surface(self):
        return self._ConstrainedFilling.Surface()


class CoonsSurface(_ConstrainedFillingSurface):
    """Create a Coons Surface bound by 3 or 4 connecting curves"""

    __initargs__ = ['curves']

    curves = Input([], validator=LengthInRange(3, 4))

    tolerance = Input(1e-6)

    @Attribute
    def _Bounds(self):
        return [_create_simple_bound(curve, self.tolerance)
                for curve in self.curves]


class FillSurface(_ConstrainedFillingSurface):
    __initargs__ = ['simple_bounds', 'tangent_bounds', 'tangent_surfaces']

    simple_bounds = Input([])
    tangent_bounds = Input([])
    tangent_surfaces = Input([])

    tolerance = Input(1e-6)
    angular_tolerance = Input(1e-4)

    @Attribute
    def _edge_face_pairs(self):
        # get faces from the given surfaces
        faces = []
        for surface in self.tangent_surfaces:
            faces.extend(surface.faces)
        pairs = [(find_edge_on_face(crv, face, include_midpoint=False), face)
                 for crv, face in zip(self.tangent_bounds, faces)]
        edges, _ = zip(*pairs)
        if not all(edges):
            idx = edges.index(None)
            msg = "{} does not bound {}".format(self.tangent_bounds[idx],
                                                self.tangent_surfaces[idx])
            raise RuntimeError(msg)
        return pairs

    @Attribute
    def _Bounds(self):
        if self.simple_bounds:
            simple_bounds = [_create_simple_bound(curve, self.tolerance)
                             for curve in self.simple_bounds]
        else:
            simple_bounds = []

        if self.tangent_bounds and self.tangent_surfaces:
            surface_bounds = [_create_tangent_bound(face, edge,
                                                    self.tolerance,
                                                    self.angular_tolerance)
                              for edge, face in self._edge_face_pairs]
        else:
            surface_bounds = []

        return simple_bounds + surface_bounds


def _create_simple_bound(curve, tolerance):
    hcurve = GeomAdaptor_HCurve(curve.Handle_Geom_Curve).handle
    return GeomFill_SimpleBound(hcurve, tolerance, 0.0).handle


def _create_tangent_bound(face, edge, tolerance, angular_tolerance):
    # create 2d curve in face parametric space
    geom2d_curve = BRepAdaptor_Curve2d(edge.TopoDS_Edge,
                                       face.TopoDS_Face)
    # convert curves & surfaces to adaptor curves
    hcurve = Geom2dAdaptor_HCurve(geom2d_curve).handle
    hsurface = GeomAdaptor_HSurface(face.Handle_Geom_Surface).handle

    # create Adaptor3d_CurveOnSurface required by GeomFill_BoundWithSurf
    curve_on_surface = Adaptor3d_CurveOnSurface(hcurve, hsurface)
    return GeomFill_BoundWithSurf(curve_on_surface,
                                  tolerance,
                                  angular_tolerance).handle


if __name__ == '__main__':
    from parapy.geom import Point, VX, VZ, BSplineCurve, ExtrudedShell, \
        InterpolatedCurve, LineSegment
    from parapy.gui import display

    pts1 = [Point(0, 0, 0), Point(-2, 2, 0), Point(2, 3, 0), Point(0, 4, 0)]
    crv1 = BSplineCurve(pts1)

    pts2 = [Point(0, 0, 0), Point(3, 0, 3)]
    tan2 = [VZ, VX]
    crv2 = InterpolatedCurve(points=pts2, tangents=tan2)

    pts3 = [Point(0, 4, 0), Point(3, 4, 4)]
    tan3 = [VZ, VX]
    crv3 = InterpolatedCurve(points=pts3, tangents=tan3)

    pts4 = [Point(3, 0, 3), Point(3, 1, 2), Point(3, 3, 4), Point(3, 4, 4)]
    crv4 = BSplineCurve(pts4)

    curves = [crv1, crv2, crv3, crv4]

    coons = CoonsSurface(curves=curves, tolerance=1e-4)

    pts5 = [Point(0, 0, -1), Point(2, 2, -1), Point(0, 3, -1), Point(0, 4, -1)]
    crv5 = BSplineCurve(pts5)
    line1 = LineSegment(pts1[0], pts5[0])
    line2 = LineSegment(pts1[-1], pts5[-1])

    bound1 = CoonsSurface([crv1, line1, line2, crv5])

    bound2 = ExtrudedShell(profile=crv4, distance=1.0, direction=VX)

    fill = FillSurface(simple_bounds=[crv2, crv3],
                       tangent_bounds=[crv1, crv4],
                       tangent_surfaces=[bound1, bound2])

    display([coons, fill])
