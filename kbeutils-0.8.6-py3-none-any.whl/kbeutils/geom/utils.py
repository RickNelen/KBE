import numpy as np

from kbeutils.core.utils import eps


def orientation_to_euler(r_mat, seq='zyx', units='rad'):
    """
    Convert orientation matrix to euler angles
    :param r_mat: orientation matrix
    :param seq: orientation sequence 'zyx', 'zyz' or 'xyz'
    :param units: 'deg' or 'rad'

    :return angles
    :rtype tuple
    """

    valid_seq = ['zyx', 'zyz', 'xyz']
    do_repeat = [False, True, False]

    if seq not in valid_seq:
        ValueError('Invalid sequence.')

    parity = int(seq != 'zyx')
    next_axis = [1, 2, 0, 1]

    if seq[2] == 'z':
        i = 2
    else:
        i = 0

    j = next_axis[i+parity]
    k = next_axis[i-parity+1]

    r_mat = np.matrix(r_mat)

    if do_repeat[valid_seq.index(seq)]:
        sy = np.sqrt(r_mat[i, j]*r_mat[i, j] + r_mat[i, k]*r_mat[i, k])
        singular = sy < 10 * eps

        if singular:
            eul = (np.arctan2(-r_mat[j, k], r_mat[j, j]),
                   np.arctan2(sy, r_mat[i, i]), 0)
        else:
            eul = (np.arctan2(r_mat[i, j], r_mat[i, k]),
                   np.arctan2(sy, r_mat[i, i]),
                   np.arctan2(r_mat[j, i], -r_mat[k, i]))
    else:
        sy = np.sqrt(r_mat[i, i]*r_mat[i, i] + r_mat[j, i]*r_mat[j, i])
        singular = sy < 10 * eps

        if singular:
            eul = (np.arctan2(r_mat[j, k], r_mat[j, j]),
                   np.arctan2(-r_mat[k, i], sy), 0)
        else:
            eul = (np.arctan2(-r_mat[k, j], r_mat[k, k]),
                   np.arctan2(-r_mat[k, i], sy),
                   np.arctan2(r_mat[j, i], r_mat[i, i]))

    if units == 'rad':
        return eul
    elif units == 'deg':
        return tuple(np.rad2deg(eul))
    else:
        ValueError('Invalid angle units')


def funspace(start, stop, dist, num=100):
    """
    Generate a range with (trigonometric) functions
    :param start: starting number
    :param stop: ending number (inclusive)
    :param dist: distribution type
    :param num: number of points

    :return the range
    :rtype np.array
    """
    if num == 1:
        return stop

    if dist == 'linear':
        def fn(u): return u
    elif dist == 'cosine':
        def fn(u): return 1 - 0.5*(1+np.cos(np.pi * u))
    elif dist == 'halfcosine':
        def fn(u): return 1 - np.cos(np.pi * u/2)
    elif dist == 'halfsine':
        def fn(u): return np.sin(np.pi * u/2)
    elif dist == 'arcsine':
        def fn(u): return 0.5 - np.arcsin(1-2*u)/np.pi
    else:
        raise ValueError('Invalid distribution: {}'.format(dist))

    return start + fn(np.linspace(0, 1, num)) * (stop-start)


def cosspace(start, stop, num=100):
    """
    cosine distributed points
    :param start: starting number
    :param stop: ending number (inclusive)
    :param num: number of points
    :return the range
    :rtype np.array
    """
    return funspace(start, stop, num=num, dist='cosine')
