#!/usr/bin/env python
# -*- coding: utf-8 -*-

""" Functions and classes for airfoil processing
"""

from math import sqrt, pi, sin, cos, asin, atan

import numpy as np
import scipy.special

from kbeutils.geom import funspace, cosspace


def _create_coordinates(x, z):
    y = (0.0,) * len(x)
    return list(zip(tuple(x), y, tuple(z)))


def read_selig_airfoil(file_path):
    """
    Read Selig (.dat) airfoil file
    :param file_path: airfoil file
    :return coordinates
    :rtype list(tuple(x, y, z))
    """
    with open(file_path, 'r') as dat_file:
        lines = dat_file.readlines()

    # % first line might contain text
    head_line = lines[0]
    tail_lines = lines[1:]

    def to_float(line):
        return tuple(float(num) for num in line.split())

    tail_data = tuple(coords for coords in (to_float(line)
                                            for line in tail_lines))

    # try to convert the first line and check if it's a valid coordinate
    try:
        head_data = to_float(head_line)
        if len(head_data) == 2 and head_data[1] < 1:
            af_data = (head_data,) + tail_data
        else:
            af_data = tail_data
    except ValueError:
        af_data = tail_data

    x, z = zip(*af_data)
    pnts = _create_coordinates(x, z)
    return ensure_order(pnts)


def ensure_order(pnts):
    """Re-order point to go from TE->LE->TE in a CCW direction"""
    x, _, _ = zip(*pnts)

    le_idx = np.argmin(x)
    te_idx = np.argmax(x)

    # re-order for the case the airfoil is defined as LE->TE
    if le_idx < te_idx:
        side_1 = pnts[le_idx:te_idx + 1]
        side_2 = pnts[te_idx + 2:]
        if side_2[0][0] > side_2[-1][0]:
            side_2 = side_2[::-1]
        pnts = side_1 + side_2

    le_idx = np.argmin(x)

    side_1 = pnts[:le_idx]
    side_2 = pnts[le_idx:]

    # compare midpoints
    if side_1[int(len(side_1) / 2)][2] < side_2[int(len(side_2) / 2)][2]:
        pnts = pnts[::-1]

    return pnts


def _generate_x_ordinate(n_points):
    # use integer division and add 1 t upper curve
    upper = funspace(start=0, stop=1,
                     dist='halfcosine',
                     num=n_points // 2 + 1)
    lower = funspace(start=0, stop=1,
                     dist='halfcosine',
                     num=n_points // 2)

    # in case of even number of points, drop first point
    # of the upper curve to avoid duplicate point at le
    if n_points % 2 == 0:
        upper = upper[1:]

    return upper, lower


def naca_4_airfoil(designation, n_points=200):
    """
    NACA 4-digit airfoil coordinates
    :param designation: NACA-4 digit airfoil name
    :type designation: str
    :param n_points: number of points
    :return: coordinates
    :rtype list(tuple(x, y, z))
    """
    if len(designation) != 4:
        ValueError('Invalid NACA 4 airfoil: {}'.format(designation))

    max_camber = float(designation[0]) / 100
    max_camber_loc = float(designation[1]) / 10
    max_thickness = float(designation[2:4]) / 100

    def camber_fn(x):
        if x < max_camber_loc:
            z = ((max_camber / max_camber_loc ** 2) *
                 (2 * max_camber_loc * x - x ** 2))
            grad = ((2 * max_camber / max_camber_loc ** 2) *
                    (max_camber_loc - x))
        else:
            z = ((max_camber / (1 - max_camber_loc) ** 2) *
                 (1 - 2 * max_camber_loc + 2 * max_camber_loc * x - x ** 2))
            grad = ((2 * max_camber / (1 - max_camber_loc) ** 2) *
                    (max_camber_loc - x))
        return z, grad

    def get_x_ordinate(x, thickness, gradient, side):
        if side == 'upper':
            direction = -1
        elif side == 'lower':
            direction = 1
        else:
            assert False
        return x + direction * thickness * (gradient / sqrt(1 + gradient ** 2))

    def get_z_ordinate(z, thickness, gradient, side):
        if side == 'upper':
            direction = 1
        elif side == 'lower':
            direction = -1
        else:
            assert False
        return z + direction * thickness * (1 / sqrt(1 + gradient ** 2))

    x_ref = _generate_x_ordinate(n_points)

    pnts = []
    for x_side, side in zip(x_ref, ('upper', 'lower')):
        camber_z, grad = zip(*map(camber_fn, x_side))
        af_thickness = list(map(lambda x: _naca_thickness_fn(max_thickness, x), x_side))

        x = np.array(list(map(lambda x, t, g: get_x_ordinate(x, t, g, side),
                              x_side, af_thickness, grad)))
        z = np.array(list(map(lambda z, t, g: get_z_ordinate(z, t, g, side),
                              camber_z, af_thickness, grad)))
        pnts.extend([x, z])

    x, z = _combine_upper_lower(*pnts)
    return _create_coordinates(x.tolist(), z.tolist())


def _naca_thickness_fn(max_thickness, x):
    return max_thickness * (1.4845 * x ** (1 / 2) - 0.63 * x - 1.758 * x ** 2 +
                            1.4215 * x ** 3 - 0.5180 * x ** 4)


def naca_5_airfoil(designation, n_points=200):
    """
    NACA 5-digit airfoil coordinates
    :param designation: NACA-5 digit airfoil name
    :type designation: str
    :param n_points: number of points
    :return: coordinates
    :rtype list(tuple(x, y, z))
    """
    if len(designation) != 5:
        ValueError('Invalid NACA 5 airfoil: {}'.format(designation))

    design_cl = 0.15 * float(designation[0])
    max_camber_loc = 0.05 * float(designation[1])
    is_reflex = designation[2] == '1'
    max_thickness = float(designation[3:5]) / 100

    if is_reflex:
        raise NotImplementedError("Reflexed NACA5 is not yet implemented")

    p = [1, -3, 6 * max_camber_loc, -3 * max_camber_loc ** 2]
    transition_loc = np.roots(p)[1]

    qq = ((3 * transition_loc - 7 * transition_loc ** 2 + 8 *
           transition_loc ** 3 - 4 * transition_loc ** 4) /
          (sqrt(transition_loc * (1 - transition_loc))) - 3 /
          2 * (1 - 2 * transition_loc) *
          (pi / 2 - asin(1 - 2 * transition_loc)))

    k1 = 6 * design_cl / qq

    def camber_fn(x):
        if x < transition_loc:
            z = ((1 / 6) * k1 * (x ** 3 - 3 * transition_loc * x ** 2 +
                                 transition_loc ** 2 * (3 - transition_loc) * x))
            grad = (1 / 6) * k1 * (3 * x ** 2 - 6 * transition_loc * x +
                                   transition_loc ** 2 * (3 - transition_loc))
        else:
            z = (1 / 6) * k1 * transition_loc ** 3 * (1 - x)
            grad = (-1 / 6) * transition_loc ** 3

        theta = atan(grad)

        return z, theta

    def get_x_ordinate(x, thickness, theta, side):
        if side == 'upper':
            direction = -1
        elif side == 'lower':
            direction = 1
        else:
            assert False
        return x + direction * thickness * sin(theta)

    def get_z_ordinate(z, thickness, theta, side):
        if side == 'upper':
            direction = 1
        elif side == 'lower':
            direction = -1
        else:
            assert False
        return z + direction * thickness * cos(theta)

    x_ref = _generate_x_ordinate(n_points)

    pnts = []
    for x_side, side in zip(x_ref, ('upper', 'lower')):
        camber_z, theta = zip(*map(camber_fn, x_side))
        af_thickness = list(map(lambda x: _naca_thickness_fn(max_thickness, x), x_side))

        x = np.array(list(map(lambda x, t, th: get_x_ordinate(x, t, th, side),
                                    x_side, af_thickness, theta)))
        z = np.array(list(map(lambda z, t, th: get_z_ordinate(z, t, th, side),
                                    camber_z, af_thickness, theta)))
        pnts.extend([x, z])

    x, z = _combine_upper_lower(*pnts)
    return _create_coordinates(x.tolist(), z.tolist())


def _combine_upper_lower(x_upper, z_upper, x_lower, z_lower):
    x = np.concatenate((np.flipud(x_upper), x_lower))
    z = np.concatenate((np.flipud(z_upper), z_lower))
    return x, z


def get_cst_poly_order(cst_coefficients):
    return len(cst_coefficients) - 3


def _cst_mat_shape(poly_order, x):
    return len(x), poly_order + 3


def _cst_matrix(poly_order, x, n1=0.5, n2=1.0):
    # ensure x is a 1D array
    x = np.hstack(x)

    # class function
    cls = x ** n1 * (1 - x) ** n2

    cst_mat = np.zeros(shape=_cst_mat_shape(poly_order, x))
    # shape functions
    for o in range(0, poly_order + 1):
        s = scipy.special.binom(poly_order, o) * x ** o * (1 - x) ** (poly_order - o)
        cst_mat[:, o] = cls * s

    # trailing edge thickness
    cst_mat[:, poly_order + 1] = x
    # leading edge shaping
    cst_mat[:, poly_order + 2] = x ** n2 * (1 - x) ** n1 * (1 - x) ** poly_order

    return cst_mat


def _cst_ordinate(x, cst_coefficients):
    cst_order = get_cst_poly_order(cst_coefficients)
    cst_mat = _cst_matrix(cst_order, x)
    return cst_mat.dot(cst_coefficients)


def cst_airfoil_coordinates(cst_upper, cst_lower, n_points):

    x_upper, x_lower = _generate_x_ordinate(n_points)
    z_upper = _cst_ordinate(x_upper, cst_upper)
    z_lower = _cst_ordinate(x_lower, cst_lower)

    x, z = _combine_upper_lower(x_upper, z_upper, x_lower, z_lower)
    return _create_coordinates(x.tolist(), z.tolist())


def fit_cst(x, z, poly_order):
    # remove trailing edge thickness
    z_te = z[-1]
    z_modified = z - x * z_te

    # create cst matrix and compute coefficients
    cst_mat = _cst_matrix(poly_order, x)
    coeff = np.linalg.lstsq(cst_mat, z_modified, rcond=None)[0]
    coeff[-2] = z_te
    return coeff


def fit_cst_airfoil(x, z, poly_order):
    """
    :param x: x-ordinates of the airfoil
    :type x: collections.Sequence or np.array

    :param z: z-ordinates of the airfoil
    :type z: collections.Sequence or np.array

    :param poly_order: CST order
    :type poly_order: int or collections.Sequence[int]

    :return: cst coefficients
    :rtype: tuple(list)
    """

    # ensure input is a numpy array
    x = np.array(x)
    z = np.array(z)

    nose_idx = np.argmin(x)
    x_upper = np.flipud(x[0:nose_idx + 1])
    z_upper = np.flipud(z[0:nose_idx + 1])

    x_lower = x[nose_idx:]
    z_lower = z[nose_idx:]

    # rescale coordinates so the x-range is 0..1
    def rescale(a):
        return (a - a.min()) / (a.max() - a.min())

    x_upper = rescale(x_upper)
    x_lower = rescale(x_lower)

    if isinstance(poly_order, (list, tuple)):
        if len(poly_order) == 1:
            order_upper = poly_order[0]
            order_lower = poly_order[0]
        elif len(poly_order) == 2:
            order_upper = poly_order[0]
            order_lower = poly_order[1]
        else:
            raise Exception('Invalid poly_order.')
    else:
        order_upper = poly_order
        order_lower = poly_order

    cst_upper = fit_cst(x_upper, z_upper, order_upper)
    cst_lower = fit_cst(x_lower, z_lower, order_lower)

    return cst_upper.tolist(), cst_lower.tolist()
