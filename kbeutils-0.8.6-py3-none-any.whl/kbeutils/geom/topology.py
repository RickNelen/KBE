#!/usr/bin/env python
# encoding: utf-8
#
# Copyright (c) 2019 Reno Elmendorp
#
# This code is subject to a Non-Disclosure Agreement. You have received a
# temporary copy of the code for non-commercial, educational purposes only.
#
# THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
# EITHER EXPRESSED OR  IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
# WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.


def find_edge_on_face(curve, face, include_midpoint=True, tol=None):
    the_edge = _find_equal_topo_edge(curve, face)
    if not the_edge:
        the_edge = _find_equal_edge_points(curve, face,
                                           include_midpoint=include_midpoint,
                                           tol=tol)
    return the_edge


def _find_equal_topo_edge(curve, face):
    face_edges = face.edges
    face_edge_topos = [edge.TopoDS_Edge for edge in face_edges]
    curve_topo = curve.TopoDS_Edge
    if curve_topo in face_edge_topos:
        edge_idx = face_edge_topos.index(curve_topo)
        return face_edges[edge_idx]
    else:
        return None


def _find_equal_edge_points(curve, face, include_midpoint, tol=None):
    face_edges = face.edges
    for edge, start, mid, end in zip(face_edges,
                                     [edge.start for edge in face_edges],
                                     [edge.midpoint for edge in face_edges],
                                     [edge.end for edge in face_edges]):
        predicates = [curve.start.is_almost_equal(start, tol),
                      curve.end.is_almost_equal(end, tol)]
        if include_midpoint:
            predicates.append(curve.midpoint.is_almost_equal(mid, tol))
        if all(predicates):
            the_edge = edge
            break
    else:
        the_edge = None
    return the_edge