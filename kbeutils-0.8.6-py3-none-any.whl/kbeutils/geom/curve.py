#!/usr/bin/env python
# -*- coding: utf-8 -*-

""" Curves
"""

import os.path
from collections import deque

from parapy.core import Input, Attribute
from parapy.geom import FittedCurve, Position, Orientation, TransformedCurve, ScaledCurve

from kbeutils.geom import (fit_cst_airfoil, naca_4_airfoil, naca_5_airfoil,
                           read_selig_airfoil, cst_airfoil_coordinates, get_cst_poly_order)
from kbeutils.globs import ICON_DIR


class PositionedFittedCurve(FittedCurve):
    """Fitted curve generated from points in the local reference frame"""

    __initargs__ = ['coordinates']

    # Default mesh deflection is terrible
    mesh_deflection = Input(0.0001)

    #: curve coordinates in local frame of reference
    #: :type: collections.Sequence[Point]
    coordinates = Input()

    @Attribute
    def points(self):
        return tuple(self.position.get_point(*xyz)
                     for xyz in self.coordinates)


class AirfoilCurve(PositionedFittedCurve):
    """General airfoil curve"""

    # appearance
    __icon__ = os.path.join(ICON_DIR, 'airfoil.png')
    color = Input('white')
    line_thickness = Input(2)

    # parameters for sensible airfoil fitting
    tolerance = Input(1e-5)
    max_degree = Input(3)

    #: (optional) curve_in to create an airfoil from a curve
    curve_in = Input(None)

    #: upper and lower cst order for fit
    cst_order_upper = Input(5)
    cst_order_lower = Input(5)

    _default_n_points = 200

    @Input
    def n_points(self):
        if self.curve_in is None:
            return len(self.coordinates)
        else:
            return self._default_n_points

    @Input
    def coordinates(self):
        if self.curve_in is not None:
            return self.curve_in.equispaced_points(self.n_points)
        else:
            ValueError("Either coordinates or curve_in should be defined")

    @Attribute
    def te_point(self):
        return self.start.midpoint(self.end)

    @Attribute
    def le_point(self):
        extremum = self.extremum(other=self.te_point,
                                 distance='max')
        return extremum['point']

    @Attribute
    def chord_length(self):
        return self.le_point.distance(self.te_point)

    @Attribute
    def chord_vector(self):
        return self.le_point.vector_to(self.te_point)

    @Attribute
    def plane_normal(self):
        # Solve some weird ParaPy behaviour  TODO: Figure out what is happening here
        if self.curve_in is not None:
            return self.curve_in.plane_normal
        else:
            return super().plane_normal

    @Attribute
    def normalized_airfoil(self):
        if not self.is_planar:
            raise ValueError("Curve should be planar.")
        # y-axis is -normal since curve goes anti-clockwise w.r.t. its local y-axis
        old_position = Position(location=self.le_point,
                                orientation=Orientation(x=self.chord_vector, y=-self.plane_normal))
        new_position = Position()
        positioned_curve = TransformedCurve(curve_in=self, from_position=old_position,
                                            to_position=new_position)
        scaled_curve = ScaledCurve(curve_in=positioned_curve,
                                   factor=1.0 / self.chord_length,
                                   reference_point=positioned_curve.position.point)
        return AirfoilCurve(curve_in=scaled_curve)

    @Attribute
    def _cst_coefficients(self):
        x, _, z = zip(*self.coordinates)
        return fit_cst_airfoil(x, z,
                               (self.cst_order_upper, self.cst_order_lower))

    @Attribute
    def cst_upper(self):
        return self._cst_coefficients[0]

    @Attribute
    def cst_lower(self):
        return self._cst_coefficients[1]


class Naca4AirfoilCurve(AirfoilCurve):
    """Naca 4-digit airfoil curve"""

    __initargs__ = ['designation']

    #: NACA 4-digit designation
    #: :type: str
    designation = Input()

    #: number of points generated
    #: :type: int
    n_points = Input(200)

    @Attribute
    def coordinates(self):
        return naca_4_airfoil(self.designation, self.n_points)


class Naca5AirfoilCurve(AirfoilCurve):
    """Naca 5-digit airfoil curve"""

    __initargs__ = ['designation']

    #: NACA 5-digit designation
    #: :type: str
    designation = Input()

    #: number of points generated
    #: :type: int
    n_points = Input(200)

    @Attribute
    def coordinates(self):
        return naca_5_airfoil(self.designation, self.n_points)


class SeligAirfoilCurve(AirfoilCurve):
    """Curve generated from Selig airfoil file"""

    __initargs__ = ['filename']

    #: airfoil Selig (.dat) file name
    filename = Input()

    @Attribute
    def _filename(self):
        if os.path.isfile(self.filename):
            return self.filename
        elif os.path.isfile(self.filename + '.dat'):
            return self.filename + '.dat'
        else:
            raise ValueError('Invalid airfoil file path')

    @Attribute
    def coordinates(self):
        return read_selig_airfoil(self._filename)


class CSTAirfoil(AirfoilCurve):
    """Curve generated from CST coefficients"""

    __initargs__ = ['cst_upper', 'cst_lower']

    #: CST coefficients of upper half
    cst_upper = Input()

    #: CST coefficients of lower half
    cst_lower = Input()

    #: Number of points (per half) (default = 100)
    n_points = Input(100)

    #: Point distribution (default = cosine)
    x_distribution = Input('cosine')

    @Attribute
    def coordinates(self):
        return cst_airfoil_coordinates(cst_upper=self.cst_upper,
                                       cst_lower=self.cst_lower,
                                       n_points=self.n_points)

    @Attribute
    def cst_order_upper(self):
        return get_cst_poly_order(self.cst_upper)

    @Attribute
    def cst_order_lower(self):
        return get_cst_poly_order(self.cst_lower)


def order_connecting_edges(edges, tol=1e-5):
    """Order edges to form a continuous chain

    :param edges: ParaPy edges
    :param tol: search tolerance
    :return edges, remaining_edges"""

    def propagated_search(start_edge, other_edges, direction, tol):

        if direction == 'start':
            other_direction = 'end'
        elif direction == 'end':
            other_direction = 'start'
        else:
            raise ValueError('Invalid direction.')

        edge_chain = deque([start_edge])

        def add_to_chain(edge, reverse=False):
            other_edges.remove(edge)
            if reverse:
                edge = edge.reversed
            if direction == 'start':
                edge_chain.appendleft(edge)
            else:
                edge_chain.append(edge)

        while other_edges:
            if direction == 'start':
                pnt = getattr(edge_chain[0], direction)
            else:
                pnt = getattr(edge_chain[-1], direction)
            for edge in other_edges:
                if getattr(edge, other_direction).is_almost_equal(pnt, tol=tol):
                    add_to_chain(edge)
                    break
                elif getattr(edge, direction).is_almost_equal(pnt, tol=tol):
                    add_to_chain(edge, True)
                    break
            else:
                break

        return list(edge_chain), other_edges

    start_edge = edges[0]
    other_edges = edges[1:]
    edge_chain, remaining_edges = propagated_search(start_edge=start_edge,
                                                    other_edges=other_edges,
                                                    direction='end',
                                                    tol=tol)
    if edges:
        (backward_edges,
         remaining_edges) = propagated_search(start_edge=start_edge,
                                              other_edges=remaining_edges,
                                              direction='start',
                                              tol=tol)
        edge_chain = backward_edges[:-1] + edge_chain
    return edge_chain, remaining_edges


def airfoil_points_in_xy_plane(curve_in, n_points=200):
    if not isinstance(curve_in, AirfoilCurve):
        curve_in = AirfoilCurve(curve_in=curve_in)

    oriented_curve = TransformedCurve(curve_in=curve_in.normalized_airfoil,
                                      from_position=curve_in.position,
                                      to_position=curve_in.position.rotate90('-x'))

    return oriented_curve.equispaced_points(n_points)
