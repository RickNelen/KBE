#!/usr/bin/env python
# -*- coding: utf-8 -*-

""" Intersect fuselage surface and write to CPACS file
"""
from parapy.core import Input, Attribute, Part, child
from parapy.core.decorators import action
from parapy.exchange import STEPReader
from parapy.geom import (GeomBase, Point, Plane, VX,
                         IntersectedShapes, Wire, ScaledShape, SewnSolid,
                         MirroredShape, VZ)


from kbeutils.geom import order_connecting_edges, orientation_to_euler, funspace
from kbeutils.io.xmlfile import CPACSFile

FUSELAGES_PATH = 'vehicles/aircraft/model/fuselages'
PROFILES_PATH = 'vehicles/profiles/fuselageProfiles'


class FuselageUnlofter(GeomBase):

    shape_in = Input()

    n_sections = Input(50)
    n_points = 50
    distribution = Input('cosine')

    @Attribute
    def face_extrema(self):
        ref_obj = Point(0, 0, 0)
        extrema_result = [face.extrema(ref_obj)
                          for face in self.shape_in.faces]

        points = []
        for res in extrema_result:
            if res:
                [points.append(p['point']) for p in res]
        return sorted(points, key=lambda p: p.x)

    @Attribute
    def fuselage_extrema(self):
        return [self.face_extrema[0], self.face_extrema[-1]]

    @Attribute
    def x_ordinates(self):
        x = funspace(start=self.fuselage_extrema[0].x,
                     stop=self.fuselage_extrema[1].x,
                     dist=self.distribution,
                     num=self.n_sections+2)
        # omit first and last to ensure intersection
        return x[1:-1]

    @Part(in_tree=False)
    def intersection_planes(self):
        return Plane(quantify=self.n_sections,
                     reference=Point(self.x_ordinates[child.index], 0, 0),
                     normal=VX)

    @Part
    def intersections(self):
        return IntersectedShapes(quantify=self.n_sections,
                                 shape_in=self.shape_in,
                                 tool=self.intersection_planes[child.index])

    @Attribute
    def ordered_edges(self):
        edges = [section.section_edges
                 for section in self.intersections]

        # order edges to be able to concatenate the edges
        ordered_edges = [order_connecting_edges(edgs) for edgs in edges]

        # return only the chains, check for remains
        chains, remains = zip(*ordered_edges)

        if any(remains):
            print("Non-connecting edges found.")
        return chains

    @Attribute
    def intersection_points(self):
        wires = [Wire(edges)
                 for edges in self.ordered_edges]
        return [wire.equispaced_points(self.n_points+1)[:-1]
                for wire in wires]

    #: counter-clockwise ordered points
    @Attribute
    def ccw_points(self):
        ccw_points = []
        for pnts in self.intersection_points:
            # get index of lowest point with a positive y-ordinate
            bottom_pnt = min(filter(lambda p: p.y > 0, pnts),
                             key=lambda p: p.z)
            idx = [id(p) for p in pnts].index(id(bottom_pnt))

            if idx == len(pnts)-1:
                pnts.reverse()
                idx = 0

            if pnts[idx+1].y < 0:
                pnts.reverse()
                idx = len(pnts)-idx-1

            pnts = pnts[idx:] + pnts[:idx]

            ccw_points.append(pnts)

        return ccw_points


class CPACSFuselageWriter(GeomBase):

    cpacs_in = Input(None)
    cpacs_target = Input('ToolOutput.xml')

    fuselage_name = Input('UnloftedFuselage')
    fuselage_uid = Input('Aircraft1_Fuselage1')

    point_list = Input()

    @Attribute
    def _cpacs_file(self):
        if self.cpacs_in is not None:
            return CPACSFile(self.cpacs_in)
        else:
            cpacs = CPACSFile.new(self.cpacs_target)
            cpacs.add_cpacs_header('FuselageUnlofter')
            return cpacs

    @action(label="Write fuselage to CPACS")
    def write_cpacs(self):
        cpacs = self._cpacs_file
        fuselage_el = self._create_cpacs_fuselage(cpacs)
        self._write_cpacs_section(cpacs, fuselage_el)

        # check for model uID
        for idx, el in enumerate(cpacs.root.xpath('//model')):
            if 'uID' not in el.attrib:
                el.attrib['uID'] = 'model_{}ID'.format(idx + 1)

        self._cpacs_file.write(self.cpacs_target)

        print("CPACS File {} written.".format(self.cpacs_target))

    def _create_cpacs_fuselage(self, cpacs):
        fuselages_el = cpacs.create_element_path(cpacs.root, FUSELAGES_PATH)
        fuselage_el = cpacs.create_element(fuselages_el, 'fuselage')

        fuselage_el.attrib['uID'] = self.fuselage_uid
        cpacs.add_text_element(fuselage_el, 'name', self.fuselage_name)

        euler_angles = orientation_to_euler(self.orientation, 'xyz', 'deg')
        cpacs.add_transformation(parent=fuselage_el,
                                 translation=self.position.location,
                                 rotation=euler_angles)

        return fuselage_el

    def _write_cpacs_section(self, cpacs, fuselage_el):
        profiles_el = cpacs.create_element_path(cpacs.root, PROFILES_PATH)
        setions_el = cpacs.create_element(fuselage_el, 'sections')
        positionings_el = cpacs.create_element(fuselage_el, 'positionings')
        segments_el = cpacs.create_element(fuselage_el, 'segments')

        profile_x = [0]
        section_uids = []
        element_uids = []
        for idx, pnts in enumerate(self.point_list):
            base_name = 'UnloftedFuselage_{0}'.format(idx + 1)

            # Profiles
            profile_name = 'Profile_' + base_name
            profile_uid = profile_name + 'ID'

            x, y, z = zip(*pnts)
            profile_x.append(x[0])
            x = (0,) * len(x)
            cpacs.add_profile(parent=profiles_el,
                              profile_tag='fuselageProfile',
                              name=profile_name,
                              uid=profile_uid,
                              xyz=(x, y, z))

            # Sections
            section_name = 'Section_' + base_name
            section_uid = section_name + 'ID'
            section_uids.append(section_uid)
            section_el = cpacs.create_element(setions_el, 'section')
            section_el.attrib['uID'] = section_uid
            cpacs.add_text_element(section_el, 'name', section_name)
            cpacs.add_transformation(section_el)

            # Elements
            element_name = 'Element_' + base_name
            element_uid = element_name + 'ID'
            element_uids.append(element_uid)
            element_el = cpacs.create_element_path(section_el,
                                                   'elements/element')
            element_el.attrib['uID'] = element_uid
            cpacs.add_text_element(element_el, 'name', element_name)
            cpacs.add_text_element(element_el, 'profileUID', profile_uid)
            cpacs.add_transformation(element_el)

            # Positionings
            pos_name = 'Positioning_' + base_name
            pos_uid = pos_name + 'ID'
            pos_el = cpacs.create_element(positionings_el, 'positioning')
            pos_el.attrib['uID'] = pos_uid
            cpacs.add_text_element(pos_el, 'name', pos_name)
            cpacs.add_num_element(pos_el, 'length',
                                  profile_x[-1] - profile_x[-2])
            cpacs.add_num_element(pos_el, 'sweepAngle', 90)
            cpacs.add_num_element(pos_el, 'dihedralAngle', 0)
            if idx > 0:
                cpacs.add_text_element(pos_el,
                                       'fromSectionUID', section_uids[-2])
            cpacs.add_text_element(pos_el, 'toSectionUID', section_uids[-1])

            # Segments
            if idx > 1:
                segment_name = 'Segment_UnloftedFuselage_{0}'.format(idx)
                segment_uid = segment_name + 'ID'
                segment_el = cpacs.create_element(segments_el, 'segment')
                segment_el.attrib['uID'] = segment_uid
                cpacs.add_text_element(segment_el, 'name', segment_name)
                cpacs.add_text_element(segment_el,
                                       'fromElementUID', element_uids[-2])
                cpacs.add_text_element(segment_el,
                                       'toElementUID', element_uids[-1])


class STEPFuselageUnlofter(FuselageUnlofter):

    filename = Input()
    mirror = Input(False)
    scaling_factor = Input(1e-3)

    @Part
    def step_reader(self):
        return STEPReader(filename=self.filename)

    @Attribute
    def step_shell(self):
        return self.step_reader.children[0]

    @Attribute
    def all_shells(self):
        if self.mirror:
            other_side = MirroredShape(shape_in=self.step_shell,
                                       reference_point=self.position.point,
                                       vector1=VX,
                                       vector2=VZ)
            return [self.step_shell, other_side]
        else:
            return [self.step_shell]

    @Attribute
    def sewn_shape(self):
        return SewnSolid(built_from=self.all_shells,
                         tolerance=1e-3)

    @Attribute
    def shape_in(self):
        return ScaledShape(shape_in=self.sewn_shape,
                           reference_point=self.position.point,
                           factor=self.scaling_factor)


class STEPFuselageUnlofterCPACSWriter(STEPFuselageUnlofter,
                                      CPACSFuselageWriter):

    @Attribute
    def point_list(self):
        return self.ccw_points


if __name__ == '__main__':
    import os.path

    from parapy.gui import display

    from kbeutils import globs

    data_dir = globs.DATA_DIR
    unlofter = STEPFuselageUnlofterCPACSWriter(filename=os.path.join(
        data_dir,'ParsifalFuselage.stp'), mirror=True)

    display(unlofter)
