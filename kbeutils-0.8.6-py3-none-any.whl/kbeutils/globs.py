#!/usr/bin/env python
# -*- coding: utf-8 -*-

""" Module globals
"""

import os.path

_module_dir = os.path.dirname(__file__)

BIN_DIR = os.path.join(_module_dir, 'bin', '')
DATA_DIR = os.path.join(_module_dir, 'data', '')
ICON_DIR = os.path.join(DATA_DIR, 'icons', '')
AIRFOIL_DIR = os.path.join(DATA_DIR, 'airfoils', '')
